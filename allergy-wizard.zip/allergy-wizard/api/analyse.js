export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  try {
    const { system, messages } = req.body;
    const content = messages[0].content;
    const imageBlock = content.find(c => c.type === 'image');
    const textBlock  = content.find(c => c.type === 'text');

    const geminiBody = {
      system_instruction: { parts: [{ text: system }] },
      contents: [{
        parts: [
          { inline_data: { mime_type: imageBlock.source.media_type, data: imageBlock.source.data } },
          { text: textBlock.text }
        ]
      }],
      generationConfig: { maxOutputTokens: 1200 }
    };

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
      { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(geminiBody) }
    );

    const data = await response.json();
    if (!response.ok) {
      return res.status(response.status).json({ error: { message: data.error?.message || 'Gemini API error' } });
    }

    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    // Return in Anthropic format so the app's existing parsing code works unchanged
    res.json({ content: [{ type: 'text', text }] });

  } catch (err) {
    res.status(500).json({ error: { message: err.message } });
  }
}
